import{l as o}from"./index-DdSpOZIz.js";const t=[["path",{d:"M5 12l14 0",key:"svg-0"}],["path",{d:"M5 12l6 6",key:"svg-1"}],["path",{d:"M5 12l6 -6",key:"svg-2"}]],r=o("outline","arrow-left","ArrowLeft",t);export{r as I};
//# sourceMappingURL=IconArrowLeft-ro2ccBOM.js.map
